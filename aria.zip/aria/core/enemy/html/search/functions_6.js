var searchData=
[
  ['update_5fhealth_33',['update_health',['../enemy_8c.html#a8fb17265ff5cbdcdb044fac98795ec25',1,'enemy.c']]]
];
