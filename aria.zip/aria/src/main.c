// Initialize background
init_background(&background, "assets/game/fantasyforest.png", 1);  // Use fantasyforest background 